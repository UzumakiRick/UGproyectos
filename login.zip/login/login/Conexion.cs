﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace login
{
    public class Conexion
{
    private static string cadena = "Server=localhost;Database=login_db;Uid=root;Pwd=;";
    public static MySqlConnection ObtenerConexion()
    {
        MySqlConnection conexion = new MySqlConnection(cadena);
        conexion.Open();
        return conexion;
    }
}
}