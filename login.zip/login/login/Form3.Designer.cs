﻿namespace login
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            iNICIOToolStripMenuItem = new ToolStripMenuItem();
            vERUSUARIOSToolStripMenuItem = new ToolStripMenuItem();
            sALIRToolStripMenuItem = new ToolStripMenuItem();
            aYUDAToolStripMenuItem = new ToolStripMenuItem();
            qUIENESSOMOSToolStripMenuItem = new ToolStripMenuItem();
            lblBienvenida = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { iNICIOToolStripMenuItem, aYUDAToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // iNICIOToolStripMenuItem
            // 
            iNICIOToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { vERUSUARIOSToolStripMenuItem, sALIRToolStripMenuItem });
            iNICIOToolStripMenuItem.Name = "iNICIOToolStripMenuItem";
            iNICIOToolStripMenuItem.Size = new Size(54, 20);
            iNICIOToolStripMenuItem.Text = "INICIO";
            // 
            // vERUSUARIOSToolStripMenuItem
            // 
            vERUSUARIOSToolStripMenuItem.Name = "vERUSUARIOSToolStripMenuItem";
            vERUSUARIOSToolStripMenuItem.Size = new Size(180, 22);
            vERUSUARIOSToolStripMenuItem.Text = "FACTURACION";
            vERUSUARIOSToolStripMenuItem.Click += vERUSUARIOSToolStripMenuItem_Click;
            // 
            // sALIRToolStripMenuItem
            // 
            sALIRToolStripMenuItem.Name = "sALIRToolStripMenuItem";
            sALIRToolStripMenuItem.Size = new Size(180, 22);
            sALIRToolStripMenuItem.Text = "SALIR";
            // 
            // aYUDAToolStripMenuItem
            // 
            aYUDAToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { qUIENESSOMOSToolStripMenuItem });
            aYUDAToolStripMenuItem.Name = "aYUDAToolStripMenuItem";
            aYUDAToolStripMenuItem.Size = new Size(57, 20);
            aYUDAToolStripMenuItem.Text = "AYUDA";
            // 
            // qUIENESSOMOSToolStripMenuItem
            // 
            qUIENESSOMOSToolStripMenuItem.Name = "qUIENESSOMOSToolStripMenuItem";
            qUIENESSOMOSToolStripMenuItem.Size = new Size(165, 22);
            qUIENESSOMOSToolStripMenuItem.Text = "QUIENES SOMOS";
            // 
            // lblBienvenida
            // 
            lblBienvenida.AutoSize = true;
            lblBienvenida.Location = new Point(673, 34);
            lblBienvenida.Name = "lblBienvenida";
            lblBienvenida.Size = new Size(66, 15);
            lblBienvenida.TabIndex = 1;
            lblBienvenida.Text = "Bienvenido";
            lblBienvenida.Click += lblBienvenida_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblBienvenida);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form3";
            Text = "SISTEMA";
            Load += Form3_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem iNICIOToolStripMenuItem;
        private ToolStripMenuItem vERUSUARIOSToolStripMenuItem;
        private ToolStripMenuItem sALIRToolStripMenuItem;
        private ToolStripMenuItem aYUDAToolStripMenuItem;
        private ToolStripMenuItem qUIENESSOMOSToolStripMenuItem;
        private Label lblBienvenida;
    }
}