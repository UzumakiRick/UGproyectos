
using MySql.Data.MySqlClient;



namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string clave = txtClave.Text;

            using (var conexion = Conexion.ObtenerConexion())
            {
                string query = "SELECT nombre FROM usuarios WHERE usuario=@usuario AND clave=@clave";
                MySqlCommand cmd = new MySqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@clave", clave);

                var resultado = cmd.ExecuteScalar();

                if (resultado != null)
                {
                    string nombre = resultado.ToString()!;
                    MessageBox.Show("Bienvenido, " + nombre);

                    Form3 pantallaPrincipal = new Form3(nombre);
                    pantallaPrincipal.Show();
                    this.Hide(); // Oculta el formulario de login
                }
                else
                {
                    MessageBox.Show("Usuario o clave incorrectos.");
                }
            }
        }

        private void btnIrRegistro_Click(object sender, EventArgs e)
        {
            Form2 registro = new Form2();
            registro.ShowDialog(); // El usuario registra y luego vuelve al login
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show(
        "�Est�s seguro que quieres salir?",
        "Confirmar salida",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
    );

            if (resultado == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
