﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace login
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            {
                string nombre = txtNombre.Text;
                string usuario = txtUsuario.Text;
                string clave = txtClave.Text;

                if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(clave))
                {
                    MessageBox.Show("Todos los campos son obligatorios.");
                    return;
                }

                using (var conexion = Conexion.ObtenerConexion())
                {
                    string query = "INSERT INTO usuarios (nombre, usuario, clave) VALUES (@nombre, @usuario, @clave)";
                    MySqlCommand cmd = new MySqlCommand(query, conexion);
                    cmd.Parameters.AddWithValue("@nombre", nombre);
                    cmd.Parameters.AddWithValue("@usuario", usuario);
                    cmd.Parameters.AddWithValue("@clave", clave);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("✅ Usuario registrado con éxito.");
                        this.Close(); // Cierra registro y regresa al login
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Error al registrar: " + ex.Message);
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtUsuario.Clear();
            txtClave.Clear();
           
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close(); // Cierra el formulario de registro y vuelve al login
        }
    }
}
